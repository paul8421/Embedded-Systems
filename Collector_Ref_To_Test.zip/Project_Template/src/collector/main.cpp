#include <Arduino.h>
#include <Zumo32U4.h>
#include <nrf24.h>
#include <nRF24L01.h>
#include "../../libs/arduino/HardwareSerial.h"

/******************************RF***********************************/
int flag = 1;
int new_flag = 1;
char buff[2] = {'O', 'K'};
char buff1[3] = {'N', 'O', 'K'};
char buff3[1] = {10};
char reg_data[8] = {'0','0','0','0','0','0','0','0'};
uint8_t rcv_reg[32];
uint8_t rx_address[5] = {0xe1,0xf0,0xf0,0xf0,0xf0};
uint8_t tx_address[5] = {0xDF,0x31,0xD4,0x51,0x6B};
uint8_t data_array[4];
uint8_t temp;
uint8_t q = 0;
/******************************RF***********************************/

#define MODE 2
#define  INIT_PING 1
int m = 0;
int rf_int = 0;
void dance();
float angle3 = 0;
unsigned long timeOn;
uint16_t _2hex2dec(uint8_t reg1, uint8_t reg2);
int new_channel;
float drive_homing(float x1, float y1, float theta, float x2, float y2);
Zumo32U4Motors motors;
static char serial_buffer1 [80];

float find_angle(float x1, float y1, float x2, float y2);
float find_dist(float x1, float y1, float x2, float y2);
uint8_t send1_reg[2];
#define  mot_spd 210

void  send_serial_RF(uint8_t* data_array);

void setup() {
    int m =0;
    Serial1.begin(9600);
    nrf24_init();
    nrf24_config(111, 2); // on channel 11 with payload length 4
    nrf24_tx_address(tx_address);
    nrf24_rx_address(rx_address);

    send1_reg[1] = 20;
    send1_reg[0] = 0x42;
    send_serial_RF(send1_reg);
    delay(500);

    DDRD &= ~(1 << DDD2);     // Clear the PD2 pin
    // PD2 (PCINT0 pin) is now an input

    PORTD |= (1 << PORTD2);    // turn On the Pull-up
    // PD2 is now an input with pull-up enabled



    EICRA |= (1 << ISC01);    // set INT0 to trigger on falling edge
    EICRA &= ~(1 << ISC00);
    EIMSK |= (1 << INT0);     // Turns on INT0
}



void loop() {
    if (rf_int == 1) {
        rf_int = 0;
        Serial1.println("Expecting data");

        switch (rcv_reg[0]) {
            case 0x50:
                sprintf(serial_buffer1, "got ping, responding on %d\n", new_channel);
                Serial1.println(serial_buffer1);
                memset(serial_buffer1, 0, 80);
                nrf24_config(new_channel, 3);
                rcv_reg[0]++;
                if (rcv_reg[2] == 0xff)
                    rcv_reg[1]++;
                rcv_reg[2]++;
                Serial1.println("xxx");
                send_serial_RF(rcv_reg);
                break;

            case 0x60:

                Serial1.println("In 0x60");
                motors.setSpeeds(0, 0);
                delay(10);
                motors.setSpeeds(25, 25);
                flag = 0;

                nrf24_csn_digitalWrite(LOW);
                spi_transfer(FLUSH_RX);
                nrf24_csn_digitalWrite(HIGH);
                memset(rcv_reg, 0, (sizeof(uint8_t) * 32));

                break;
            case 0x61:{

                Serial1.println("OOB");
                motors.setSpeeds(0, 0);
                nrf24_powerDown();
                for (int i = 0; i < 15; i++) {
                    delay(2000);
                }
                Serial1.println("OOB done");


                uint16_t angle_decode = _2hex2dec(rcv_reg[1], rcv_reg[2]);
                memset(serial_buffer1, 0, 80);
                sprintf(serial_buffer1, "angle in int is %d\n", angle_decode);
                Serial1.println(serial_buffer1);
                float temppp = (float) angle_decode;

                temppp = temppp * 360;
                temppp = temppp / 65535;
                memset(serial_buffer1, 0, 80);
                sprintf(serial_buffer1, "converted angle in int is %d\n", temppp);
                Serial1.println(serial_buffer1);

                int temp11 = _2hex2dec(rcv_reg[3], rcv_reg[4]);

                int temp2 = _2hex2dec(rcv_reg[5], rcv_reg[6]);//rcv_reg[5]*256 + rcv_reg[6];
                angle3 = drive_homing((float) temp11 / 100, (float) temp2 / 100, temppp, 0, 0);
                dance();

                flag = 0;
                break;
            }
            case 0x43 :

                break;
            case 0x44:
                motors.setSpeeds(55,25);
                break;
            case 0x45:
                motors.setSpeeds(0, 0);
                break;
            case 0x62:
                motors.setSpeeds(0, 0);
                motors.setSpeeds(-mot_spd, -mot_spd);
                delay(500);
                motors.setSpeeds(0, 0);
                break;



        }
    }
}


void  send_serial_RF(uint8_t * data_array)
{
    nrf24_send(data_array);

    while (nrf24_isSending());
    temp = nrf24_lastMessageStatus();

    if (temp == NRF24_TRANSMISSON_OK)
    {
        Serial1.println("TX OK");

    }
    else if (temp == NRF24_MESSAGE_LOST) {
        {
            Serial1.println("TX NNNNOK");
        }
    }

    /* Retranmission count indicates the tranmission quality */
    temp = nrf24_retransmissionCount();
    /* Optionally, go back to RX mode ... */
    nrf24_powerUpRx();
    delay(200);
}

float find_angle(float x1, float y1, float x2, float y2)
{
    float theta,x_diff,y_diff, tan_theta;
    x_diff = x2 - x1;
    y_diff = y2 - y1;
    tan_theta = (y2-y1)/(x2-x1);
    theta = atan(tan_theta);
    if (x_diff >= 0 && y_diff < 0 )  // 4th quad
    {
        theta = 2*(22/7) + theta;
    }
    else if ((x_diff < 0 && y_diff >=0) || (x_diff < 0 && y_diff <0)  ) // 2nd quad and 3rd quad
    {
        theta = theta + (22/7);
    }

    theta = theta*(180/3.14285714);
    return theta;
}

float find_dist(float x1, float y1, float x2, float y2)
{
    float s_dist_x, s_dist_y, s_sdist, dist;
    s_dist_x = (x2-x1)*(x2-x1);
    s_dist_y = (y2-y1)*(y2-y1);
    s_sdist = s_dist_x+s_dist_y;
    dist = sqrt(s_sdist);
    return dist;
}

void turn_around(float angle)
{
    float angle1 = 360-angle;
    delay(1000);
    motors.setSpeeds(-mot_spd,mot_spd);
    delay(angle1*4.1);
    motors.setSpeeds(0,0);
}

float drive(float x1, float y1, float x2, float y2) {
    float angle = find_angle(x1, y1, x2, y2);
    float dist = find_dist(x1, y1, x2, y2);
    int dist1 = dist * 400;
    int time_motors = angle * 4.1;

    delay(1000);
    motors.setSpeeds(-mot_spd, mot_spd);
    delay(time_motors);
    motors.setSpeeds(0, 0);


    motors.setSpeeds(mot_spd, mot_spd);
    delay(dist1);
    motors.setSpeeds(0, 0);

    return angle;

}


float drive_homing(float x1, float y1, float theta, float x2, float y2) {
    Serial1.println(("In drive\n"));
    delay(2000);
    float angle = find_angle(x1, y1, x2, y2) - theta;
    float dist = find_dist(x1, y1, x2, y2);
    int dist1 = dist * 400;
    int time_motors = angle * 4.1;

    delay(1000);
    motors.setSpeeds(-mot_spd, mot_spd);
    delay(time_motors);
    motors.setSpeeds(0, 0);


    motors.setSpeeds(mot_spd, mot_spd);
    delay(dist1);
    motors.setSpeeds(0, 0);

    return angle;

}


void dance()
{
    int i = 0;
    while(i<5)
    {
        motors.setSpeeds(mot_spd, -mot_spd);
        delay(100);
        motors.setSpeeds(-mot_spd, mot_spd);
        delay(100);
        i++;
    }
    motors.setSpeeds(0, 0);
}


ISR (INT0_vect)
{
    Serial1.println("in interrupt");

    if(nrf24_dataReady()){
        nrf24_getData(rcv_reg);
        rf_int = 1;}
    if(rcv_reg[0] == 0x43)
    {
        rf_int = 0;
        nrf24_config(rcv_reg[1], 15);
        new_channel = rcv_reg[1];
        sprintf(serial_buffer1, "configured new channel %d\n", new_channel);
        Serial1.println(serial_buffer1);
        memset(serial_buffer1, 0, 80);
    }
    else if(rcv_reg[0] == 0x50){
        rf_int = 0;
        sprintf(serial_buffer1, "got ping, responding on %d\n", new_channel);
        Serial1.println(serial_buffer1);
        nrf24_config(new_channel, 3);
        rcv_reg[0]++;
        if (rcv_reg[2] == 0xff)
            rcv_reg[1]++;
        rcv_reg[2]++;
        Serial1.println("xxx");
        send_serial_RF(rcv_reg);}
    else if(rcv_reg[0] == 0x61)
    {
        rf_int = 0;
        motors.setSpeeds(0, 0);
        if(new_flag)
        {
            timeOn = millis();
            new_flag = 0;
        }
        while(millis() - timeOn <= 30000)
        {
            Serial1.println("here");
            nrf24_csn_digitalWrite(LOW);
            spi_transfer(FLUSH_RX);
            nrf24_csn_digitalWrite(HIGH);
            if(nrf24_dataReady())
            {
                nrf24_getData(rcv_reg);
                if(rcv_reg[0] == 0x50){
                    sprintf(serial_buffer1, "got ping, responding on %d\n", new_channel);
                    Serial1.println(serial_buffer1);
                    nrf24_config(new_channel, 3);
                    rcv_reg[0]++;
                    if (rcv_reg[2] == 0xff)
                        rcv_reg[1]++;
                    rcv_reg[2]++;
                    Serial1.println("xxx");
                    send_serial_RF(rcv_reg);}
            }

        }
        motors.setSpeeds(-20, -20);
        new_flag = 1;
    }

    sprintf(serial_buffer1, "rcv is %x\n", rcv_reg[0]);
    Serial1.println(serial_buffer1);
    memset(serial_buffer1, 0, 80);
}


uint16_t _2hex2dec(uint8_t reg1, uint8_t reg2)
{
    char buff[50];
    uint16_t tempalisa =  (reg1 & 0xf0);

    tempalisa = (tempalisa >> 4);
    tempalisa = tempalisa * 4096;


    uint16_t tempalisa1 = (reg1 & 0x0f);
    tempalisa1 = tempalisa1*256;


    uint16_t tempalisa2 = (reg2 & 0xf0);
    tempalisa2 = tempalisa2>>4;
    tempalisa2 = tempalisa2 * 16;

    uint16_t tempalisa3 = (reg2 & 0x0f);

    uint16_t final = tempalisa+tempalisa1+tempalisa2+tempalisa3;
    memset(serial_buffer1, 0, 80);
    sprintf(serial_buffer1, "%d\n final in hex2dex\n\n\n", final);
    Serial1.println(serial_buffer1);
    memset(serial_buffer1, 0, 80);

    return final;
}
