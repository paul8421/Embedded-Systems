#include <avr/io.h>
#include <avr/interrupt.h>
#include <3pi.h>
//#include <stdlib.h>
#include <nrf24.h>
#include <nRF24L01.h>
#include <math.h>
//#include "../../../../../../../Arduino/hardware/tools/avr/avr/include/time.h"
#include <stdio.h>
#include<string.h>
/******************************RF***********************************/

int rf_int = 0;

int flag = 1;
float find_angle(float x1, float y1, float x2, float y2);
float find_dist(float x1, float y1, float x2, float y2);
void dance();
float drive_homing(float x1, float y1, float theta, float x2, float y2);
uint16_t _2hex2dec(uint8_t reg1, uint8_t reg2);
#define  mot_spd 73

static char serial_buffer1 [80];
uint8_t tx_address[5] = {0xe1,0xf0,0xf0,0xf0,0xf0};
uint8_t rx_address[5] = {0x48,0xf7,0x38,0xCA,0xF5};
uint8_t data_array[32];
//0xf5ca38f748
//0x6b51d431df
uint8_t send1_reg[2];
uint8_t rcv_reg[3];

int new_channel;
char * data_rcvd;
uint8_t temp;

char to_serial[32];
/******************************RF***********************************/

void setBaudRate(unsigned long baud)

#define  MODE 2
/*  1 - RELAY
 *  2 - OTHERS
 */
#define INIT_PING 2
{
#if _SERIAL_PORTS > 1  // Orangutan X2 and SVP users
    serial_set_baud_rate(UART0, baud);
#else
    serial_set_baud_rate(baud);
#endif
}

// this code sets up timer1 for a 1s  @ 16Mhz Clock (mode 4)
void send_serial_RF(uint8_t *);
char* rcv_serial_RF();
int main(void) {
    nrf24_init();
    nrf24_config(111, 2); // on channel 11 with payload length 15
    nrf24_tx_address(tx_address);
    nrf24_rx_address(rx_address);
    /* send_reg[3] = 0x02; */
    //send_reg[2] = 0xff;
/*    send1_reg[1] = 0x15;
    send1_reg[0] = 0x42;
    send_serial_RF(send1_reg);
    delay(500);
    send1_reg[1] = 0x14;
    send1_reg[0] = 0x42;
    send_serial_RF(send1_reg);
    delay(500);
    send1_reg[1] = 0x0C;
    send1_reg[0] = 0x42;
    send_serial_RF(send1_reg);
    delay(500);*/
    send1_reg[1] = 20;
    send1_reg[0] = 0x42;
    send_serial_RF(send1_reg);
    delay(500);

    DDRD &= ~(1 << DDD2);     // Clear the PD2 pin
    // PD2 (PCINT0 pin) is now an input

    PORTD |= (1 << PORTD2);    // turn On the Pull-up
    // PD2 is now an input with pull-up enabled



    EICRA |= (1 << ISC01);    // set INT0 to trigger on falling edge
    EICRA &= ~(1 << ISC00);
    EIMSK |= (1 << INT0);     // Turns on INT0
    int i = 0;
    int bytes;
    setBaudRate(9600);
    int hi, lo;
    float angle3 = 0;
    serial_send_blocking("hi\n", sizeof("hi\n"));
    send_serial_RF(send1_reg);
    sei();

    // enable interrupts
    while (1) {

        delay(50);
        if (rf_int == 1) {
            rf_int = 0;
            serial_send_blocking("Expecting data\n", sizeof("Expecting data\n"));

            switch (rcv_reg[0]) {
                case 0x50:
                    sprintf(to_serial, "got ping, responding on %d\n", new_channel);
                    serial_send_blocking(to_serial, sizeof(to_serial));
                    nrf24_config(new_channel, 3);
                    rcv_reg[0]++;
                    if (rcv_reg[2] == 0xff)
                        rcv_reg[1]++;
                    rcv_reg[2]++;
                    serial_send_blocking("xxx\n", sizeof("xxx\n"));
                    send_serial_RF(rcv_reg);
                    break;
                case 0x51:

                    nrf24_config(new_channel, 3);
                    serial_send_blocking("rcv pong\n", sizeof("rcv pong\n"));
                    serial_send_blocking(to_serial, sizeof(to_serial));
                    break;
                case 0x60:
                    //nrf24_config(new_channel, 7);

                    serial_send_blocking("In 0x60\n", sizeof("In 0x60\n"));
                    set_motors(0, 0);
                    delay(10);
                    set_motors(25, 25);
                    flag = 0;
                    //delay(100);

                    nrf24_csn_digitalWrite(LOW);
                    spi_transfer(FLUSH_RX);
                    nrf24_csn_digitalWrite(HIGH);
                    memset(rcv_reg, 0, (sizeof(uint8_t) * 32));

                    break;
                case 0x61:{
                    play_frequency(6000, 150, 15);
                    serial_send_blocking("OOB\n", sizeof("OOB\n"));
                    set_motors(0, 0);
                    nrf24_powerDown();
                    for (int i = 0; i < 15; i++) {
                        delay(2000);
                    }
                    serial_send_blocking("OOB done\n", sizeof("OOB done\n"));
                    //play_frequency(6000, 150, 15);


                    uint16_t angle_decode = _2hex2dec(rcv_reg[1], rcv_reg[2]);
                    memset(serial_buffer1, 0, 80);
                    sprintf(serial_buffer1, "angle in int is %d\n", angle_decode);
                    serial_send_blocking(serial_buffer1, sizeof(serial_buffer1));
                    float temppp = (float) angle_decode;

                    temppp = temppp * 360;
                    temppp = temppp / 65535;
                    memset(serial_buffer1, 0, 80);
                    sprintf(serial_buffer1, "converted angle in int is %d\n", temppp);
                    serial_send_blocking(serial_buffer1, sizeof(serial_buffer1));
                    delay(500);
                    int temp11 = _2hex2dec(rcv_reg[3], rcv_reg[4]);

                    int temp2 = _2hex2dec(rcv_reg[5], rcv_reg[6]);//rcv_reg[5]*256 + rcv_reg[6];
                    angle3 = drive_homing((float) temp11 / 100, (float) temp2 / 100, temppp, 0, 0);
                    dance();

                    flag = 0;
                    break;
                }
                case 0x43 :
                    /* play_frequency(6000, 150, 15);
                     sprintf(to_serial,"Configuring channel %d\n",data_array[0]);
                     serial_send_blocking(to_serial, sizeof(to_serial));
                     nrf24_config(data_array[1], 15);*/
                    break;
                case 0x44:
                    //decide what to put here
                case 0x45:
                    set_motors(0, 0);
                    break;
                case 0x62:
                    set_motors(0, 0);
                    set_motors(-mot_spd, -mot_spd);
                    delay(1000);
                    set_motors(0, 0);
                    break;



            }
            serial_send_blocking("\n", sizeof("\n"));
        }
    }
}

void  send_serial_RF(uint8_t* data_array)
{
    cli();
    /* Automatically goes to TX mode */
    nrf24_send(data_array);

    /* Wait for transmission to end */
    while (nrf24_isSending());
    /* Make analysis on last tranmission attempt */
    temp = nrf24_lastMessageStatus();

    if (temp == NRF24_TRANSMISSON_OK)
    {
        serial_send_blocking("trans_ok\n", sizeof("trans_ok\n"));
    }
    else if (temp == NRF24_MESSAGE_LOST) {
        {
            serial_send_blocking("msg_lost\n", sizeof("msg_lost\n"));
        }
    }

    /* Retranmission count indicates the tranmission quality */
    temp = nrf24_retransmissionCount();
    /* Optionally, go back to RX mode ... */
    nrf24_powerUpRx();
    delay(200);
    sei();
}

float find_angle(float x1, float y1, float x2, float y2)
{
    float theta,x_diff,y_diff, tan_theta;
    x_diff = x2 - x1;
    y_diff = y2 - y1;
    tan_theta = (y2-y1)/(x2-x1);
    theta = atan(tan_theta);
    if (x_diff >= 0 && y_diff < 0 )  // 4th quad
    {
        theta = 2*(22/7) + theta;
    }
    else if ((x_diff < 0 && y_diff >=0) || (x_diff < 0 && y_diff <0)  ) // 2nd quad and 3rd quad
    {
        theta = theta + (22/7);
    }

    theta = theta*(180/3.14285714);
    return theta;
}

float find_dist(float x1, float y1, float x2, float y2)
{
    float s_dist_x, s_dist_y, s_sdist, dist;
    s_dist_x = (x2-x1)*(x2-x1);
    s_dist_y = (y2-y1)*(y2-y1);
    s_sdist = s_dist_x+s_dist_y;
    dist = sqrt(s_sdist);
    return dist;
}



float drive_homing(float x1, float y1, float theta, float x2, float y2)
{
    float angle = find_angle(x1, y1, x2, y2) - theta;
    float dist = find_dist(x1, y1, x2, y2);
    int dist1 = dist*500;
    int time_motors = angle * 2.22;

    delay(3000);
    set_motors(-82,82);
    delay(time_motors);
    set_motors(0,0);

    delay(50);
    set_motors(mot_spd-2,mot_spd);
    delay((dist1)*0.5);
    set_motors((0.6*mot_spd-2), 0.6*mot_spd);
    delay(dist1*0.2);
    set_motors((0.3*mot_spd-2), 0.3*mot_spd);
    delay(dist1*0.3);
    set_motors(0,0);
    return angle;

}

void dance()
{
    int i = 0;
    while(i<5)
    {
        set_motors(mot_spd, -mot_spd);
        delay(100);
        set_motors(-mot_spd, mot_spd);
        delay(100);
        i++;
    }
    set_motors(0, 0);
}

uint16_t _2hex2dec(uint8_t reg1, uint8_t reg2)
{
    char buff[50];
    uint16_t tempalisa =  (reg1 & 0xf0);

    tempalisa = (tempalisa >> 4);
    tempalisa = tempalisa * 4096;


    uint16_t tempalisa1 = (reg1 & 0x0f);
    tempalisa1 = tempalisa1*256;


    uint16_t tempalisa2 = (reg2 & 0xf0);
    tempalisa2 = tempalisa2>>4;
    tempalisa2 = tempalisa2 * 16;

    uint16_t tempalisa3 = (reg2 & 0x0f);

    uint16_t final = tempalisa+tempalisa1+tempalisa2+tempalisa3;
    memset(serial_buffer1, 0, 80);
    sprintf(serial_buffer1, "%d\n final in hex2dex\n\n\n", final);
    serial_send_blocking(serial_buffer1, sizeof(serial_buffer1));


    return final;
}

ISR (INT0_vect)
{
    serial_send_blocking("in interrupt\n", sizeof("in interrupt\n"));
    play_frequency(6000, 150, 7);
    if(nrf24_dataReady()){
        nrf24_getData(rcv_reg);
        rf_int = 1;}
    if(rcv_reg[0] == 0x43)
    {
        nrf24_config(rcv_reg[1], 15);
        new_channel = rcv_reg[1];
        sprintf(serial_buffer1, "configured new channel %d\n", new_channel);
        serial_send_blocking(serial_buffer1, sizeof(serial_buffer1));
        memset(serial_buffer1, 0, 80);
    }
    else if(rcv_reg[0] == 0x50){
        sprintf(to_serial, "got ping, responding on %d\n", new_channel);
        serial_send_blocking(to_serial, sizeof(to_serial));
        nrf24_config(new_channel, 3);
        rcv_reg[0]++;
        if (rcv_reg[2] == 0xff)
            rcv_reg[1]++;
        rcv_reg[2]++;
        serial_send_blocking("xxx\n", sizeof("xxx\n"));
        send_serial_RF(rcv_reg);}
    sprintf(serial_buffer1, "rcv is %x\n", rcv_reg[0]);
    serial_send_blocking(serial_buffer1, sizeof(serial_buffer1));
    memset(serial_buffer1, 0, 80);
}