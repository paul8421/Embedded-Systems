#include <Arduino.h>
#include <Zumo32U4.h>
#include <nrf24.h>
#include <nRF24L01.h>
#include "../../libs/arduino/HardwareSerial.h"

/******************************RF***********************************/
int flag = 1;
char buff[2] = {'O', 'K'};
char buff1[3] = {'N', 'O', 'K'};
char buff3[1] = {10};
char reg_data[8] = {'0','0','0','0','0','0','0','0'};

uint8_t rx_address[5] = {0xe1,0xf0,0xf0,0xf0,0xf0};
uint8_t tx_address[5] = {0xDF,0x31,0xD4,0x51,0x6B};
uint8_t data_array[4];
uint8_t temp;
uint8_t q = 0;
/******************************RF***********************************/
#define MODE 2
#define  INIT_PING 1
int m = 0;
void dance();
float drive_homing(float x1, float y1, float theta, float x2, float y2);
Zumo32U4Motors motors;
typedef struct coordinates{
    int x;
    int y;

}coordiantes;
float distances [] = {0,0,0};
float find_angle(float x1, float y1, float x2, float y2);
float find_dist(float x1, float y1, float x2, float y2);
void turn_around(float angle);
float drive(float x1, float y1, float x2, float y2);
void insertionSort(float distances[], int n);
#define  mot_spd 210

void  send_serial_RF(uint8_t* data_array);

void setup() {
    int m =0;
    Serial1.begin(9600);
    nrf24_init();
    nrf24_config(111, 10); // on channel 11 with payload length 4
    nrf24_tx_address(tx_address);
    nrf24_rx_address(rx_address);
}



void loop() {
    nrf24_tx_address(tx_address);
    nrf24_rx_address(rx_address);
    uint8_t send_reg[32];
    send_reg[2] = 0xde;
    //send_reg[3] = 0x02;
    send_reg[1] = 0xa0;
    send_reg[0] = 0x50;

    send_serial_RF(send_reg);
    delay(5000);

}


void  send_serial_RF(uint8_t* data_array)
{
    cli();
    /* Automatically goes to TX mode */
    nrf24_send(data_array);

    /* Wait for transmission to end */
    while (nrf24_isSending());
    /* Make analysis on last tranmission attempt */
    temp = nrf24_lastMessageStatus();

    if (temp == NRF24_TRANSMISSON_OK)
    {
        Serial1.println("OK");
    }
    else if (temp == NRF24_MESSAGE_LOST) {
        {
            Serial1.println("NOK");
        }
    }

    /* Retranmission count indicates the tranmission quality */
    temp = nrf24_retransmissionCount();
    /* Optionally, go back to RX mode ... */
    nrf24_powerUpRx();
    delay(200);
    sei();
}